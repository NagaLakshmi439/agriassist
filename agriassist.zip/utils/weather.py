import requests

API_KEY = "your_api_key_here"

def get_weather(city):
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric"
    res = requests.get(url).json()

    if "main" in res:
        return f"Temp: {res['main']['temp']}°C, Humidity: {res['main']['humidity']}%"
    else:
        return "City not found"
