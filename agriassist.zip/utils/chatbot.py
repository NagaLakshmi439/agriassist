def chatbot_reply(message):
    message = message.lower()

    if "crop" in message:
        return "Recommended crops: Rice, Wheat, Maize"
    elif "fertilizer" in message:
        return "Use NPK fertilizers"
    else:
        return "I am AgriAssist Bot 🌱"
